<?php
require_once 'php/config.php';
require_once 'php/db.php';
require_once 'php/functions.php';
session_start();

// Check if user is logged in and is a rider
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'rider') {
    header("Location: login.php");
    exit();
}

$pageTitle = "Book Ride";
$error = null;
$success = null;
$ride = null;

// Get ride ID from URL
$ride_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

try {
    // Get ride details without rating
    $stmt = $pdo->prepare("
        SELECT r.*, 
               u.first_name, u.last_name, u.email
        FROM rides r
        JOIN users u ON r.driver_id = u.user_id
        WHERE r.ride_id = ? AND r.status = 'active' AND r.departure_time > NOW()
    ");
    $stmt->execute([$ride_id]);
    $ride = $stmt->fetch();

    if (!$ride) {
        throw new Exception("Ride not found or no longer available.");
    }

    // Process booking
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_booking'])) {
        // Start transaction
        $pdo->beginTransaction();

        try {
            // Check if ride is still available
            $stmt = $pdo->prepare("
                SELECT available_seats 
                FROM rides 
                WHERE ride_id = ? AND status = 'active' 
                FOR UPDATE
            ");
            $stmt->execute([$ride_id]);
            $currentRide = $stmt->fetch();

            if (!$currentRide || $currentRide['available_seats'] < 1) {
                throw new Exception("Sorry, this ride is no longer available.");
            }

            // Check if user has already booked this ride
            $stmt = $pdo->prepare("
                SELECT COUNT(*) 
                FROM bookings 
                WHERE ride_id = ? AND rider_id = ? AND status != 'cancelled'
            ");
            $stmt->execute([$ride_id, $_SESSION['user_id']]);
            if ($stmt->fetchColumn() > 0) {
                throw new Exception("You have already booked this ride.");
            }

            // Create booking
            $stmt = $pdo->prepare("
                INSERT INTO bookings (ride_id, rider_id, status, created_at)
                VALUES (?, ?, 'confirmed', CURRENT_TIMESTAMP)
            ");
            $stmt->execute([$ride_id, $_SESSION['user_id']]);

            // Update available seats
            $stmt = $pdo->prepare("
                UPDATE rides 
                SET available_seats = available_seats - 1
                WHERE ride_id = ?
            ");
            $stmt->execute([$ride_id]);

            $pdo->commit();
            $_SESSION['booking_success'] = true;
            header("Location: booking-confirmation.php?id=" . $ride_id);
            exit();
        } catch (Exception $e) {
            $pdo->rollBack();
            $error = $e->getMessage();
        }
    }
} catch (Exception $e) {
    $error = $e->getMessage();
}

require_once 'includes/header.php';
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <?php if ($error): ?>
                <div class="alert alert-danger">
                    <?php echo $error; ?>
                    <a href="find-rides.php" class="btn btn-outline-danger btn-sm ms-3">Back to Search</a>
                </div>
            <?php else: ?>
                <div class="card">
                    <div class="card-header">
                        <h3 class="mb-0">Book Ride</h3>
                    </div>
                    <div class="card-body">
                        <div class="ride-details mb-4">
                            <div class="row">
                                <div class="col-md-8">
                                    <h4>Ride Details</h4>
                                    <p class="mb-2">
                                        <i class="bi bi-geo-alt text-primary"></i>
                                        From: <strong><?php echo htmlspecialchars($ride['departure_location']); ?></strong>
                                    </p>
                                    <p class="mb-2">
                                        <i class="bi bi-geo-alt-fill text-success"></i>
                                        To: <strong><?php echo htmlspecialchars($ride['destination']); ?></strong>
                                    </p>
                                    <p class="mb-2">
                                        <i class="bi bi-calendar3"></i>
                                        Date: <strong><?php echo date('l, F j, Y', strtotime($ride['departure_time'])); ?></strong>
                                    </p>
                                    <p class="mb-2">
                                        <i class="bi bi-clock"></i>
                                        Time: <strong><?php echo date('g:i A', strtotime($ride['departure_time'])); ?></strong>
                                    </p>
                                </div>
                                <div class="col-md-4 text-end">
                                    <div class="price-tag mb-2">
                                        $<?php echo number_format($ride['price_per_seat'], 2); ?>
                                    </div>
                                    <small class="text-muted">per seat</small>
                                </div>
                            </div>
                        </div>

                        <div class="alert alert-info">
                            <h5 class="alert-heading">Booking Terms</h5>
                            <ul class="mb-0">
                                <li>Please arrive 5 minutes before departure time</li>
                                <li>Payment will be made directly to the driver</li>
                                <li>Cancel at least 2 hours before departure if needed</li>
                            </ul>
                        </div>

                        <form method="POST" action="book-ride.php?id=<?php echo $ride_id; ?>" id="bookingForm">
                            <div class="form-check mb-3">
                                <input class="form-check-input" type="checkbox" id="terms" required>
                                <label class="form-check-label" for="terms">
                                    I agree to the booking terms and conditions
                                </label>
                            </div>

                            <div class="d-grid gap-2">
                                <button type="submit" name="confirm_booking" class="btn btn-primary" 
                                        onclick="return confirm('Are you sure you want to book this ride?');">
                                    Book Ride - $<?php echo number_format($ride['price_per_seat'], 2); ?>
                                </button>
                                <a href="find-rides.php" class="btn btn-outline-secondary">Cancel</a>
                            </div>
                        </form>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>