<?php
require_once 'php/config.php';
require_once 'php/db.php';
require_once 'php/functions.php';
session_start();

if (!isset($_SESSION['booking_success'])) {
    header("Location: find-rides.php");
    exit();
}

unset($_SESSION['booking_success']);

$pageTitle = "Booking Confirmation";
require_once 'includes/header.php';
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body text-center">
                    <div class="mb-4">
                        <i class="bi bi-check-circle text-success" style="font-size: 4rem;"></i>
                    </div>
                    <h2 class="mb-4">Booking Confirmed!</h2>
                    <p class="lead mb-4">Your ride has been successfully booked.</p>
                    <div class="d-grid gap-2 col-6 mx-auto">
                        <a href="my-bookings.php" class="btn btn-primary">View My Bookings</a>
                        <a href="find-rides.php" class="btn btn-outline-secondary">Find Another Ride</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>