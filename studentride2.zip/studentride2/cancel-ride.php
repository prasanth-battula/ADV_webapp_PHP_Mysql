<?php
require_once 'php/config.php';
require_once 'php/db.php';
require_once 'php/functions.php';
session_start();

// Set header to JSON
header('Content-Type: application/json');

// Check if user is logged in and is a driver
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'driver') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit();
}

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Invalid request method');
    }

    $ride_id = isset($_POST['ride_id']) ? (int)$_POST['ride_id'] : 0;

    // Start transaction
    $pdo->beginTransaction();

    // Check if ride exists and belongs to the driver
    $stmt = $pdo->prepare("
        SELECT * FROM rides 
        WHERE ride_id = ? AND driver_id = ? AND status = 'active'
    ");
    $stmt->execute([$ride_id, $_SESSION['user_id']]);
    $ride = $stmt->fetch();

    if (!$ride) {
        throw new Exception('Ride not found or cannot be cancelled');
    }

    // Update ride status to cancelled
    $stmt = $pdo->prepare("
        UPDATE rides 
        SET status = 'cancelled' 
        WHERE ride_id = ?
    ");
    $stmt->execute([$ride_id]);

    // Update all active bookings for this ride to cancelled
    $stmt = $pdo->prepare("
        UPDATE bookings 
        SET status = 'cancelled' 
        WHERE ride_id = ? AND status = 'confirmed'
    ");
    $stmt->execute([$ride_id]);

    $pdo->commit();
    echo json_encode(['success' => true, 'message' => 'Ride cancelled successfully']);

} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>