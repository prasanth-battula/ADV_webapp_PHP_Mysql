<?php
session_start();

// Include database configuration
require_once 'php/config.php';
require_once 'php/db.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// CSRF token check for security
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['token']) && $_POST['token'] == $_SESSION['token']) {
    $ride_id = $_POST['ride_id'];

    try {
        // SQL to update ride status to 'canceled'
        $stmt = $pdo->prepare("UPDATE rides SET status = 'canceled' WHERE ride_id = ? AND (driver_id = ? OR booker_id = ?)");
        $stmt->execute([$ride_id, $_SESSION['user_id'], $_SESSION['user_id']]);

        // Check if the update was successful
        if ($stmt->rowCount()) {
            $_SESSION['message'] = "Ride canceled successfully.";
        } else {
            throw new Exception("Unable to cancel the ride.");
        }
    } catch (Exception $e) {
        $_SESSION['error'] = $e->getMessage();
    }
} else {
    $_SESSION['error'] = "Invalid request.";
}

header('Location: my-rides.php');
exit();
?>
