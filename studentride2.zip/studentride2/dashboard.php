<?php
// dashboard.php
require_once 'php/config.php';
require_once 'php/db.php';
require_once 'php/functions.php';
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$pageTitle = "Dashboard";

// Get user information
$stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

// Get statistics based on user type
if ($user['user_type'] === 'driver') {
    // Driver Statistics
    $stmt = $pdo->prepare("
        SELECT 
            -- Total Rides (All non-cancelled rides)
            COUNT(DISTINCT r.ride_id) as total_rides,
            
            -- Upcoming Rides (Future rides that are active)
            COUNT(DISTINCT CASE 
                WHEN r.departure_time > NOW() AND r.status = 'active' 
                THEN r.ride_id 
                END) as upcoming_rides,
            
            -- Completed Rides (Past rides or marked as completed)
            COUNT(DISTINCT CASE 
                WHEN (r.departure_time < NOW() OR r.status = 'completed')
                AND r.status != 'cancelled' 
                THEN r.ride_id 
                END) as completed_rides,
            
            -- Total Earnings (From completed rides and confirmed bookings)
            (
                -- Earnings from completed rides
                SELECT COALESCE(SUM(
                    CASE 
                        WHEN r2.status = 'completed' 
                        THEN (
                            SELECT COUNT(*) 
                            FROM bookings b2 
                            WHERE b2.ride_id = r2.ride_id 
                            AND b2.status = 'completed'
                        ) * r2.price_per_seat
                        -- Earnings from active rides with confirmed bookings
                        WHEN r2.status = 'active' AND r2.departure_time < NOW() 
                        THEN (
                            SELECT COUNT(*) 
                            FROM bookings b2 
                            WHERE b2.ride_id = r2.ride_id 
                            AND b2.status = 'confirmed'
                        ) * r2.price_per_seat
                        ELSE 0
                    END
                ), 0)
                FROM rides r2
                WHERE r2.driver_id = r.driver_id
            ) as total_earnings
        FROM rides r
        WHERE r.driver_id = ?
        GROUP BY r.driver_id
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $stats = $stmt->fetch();

    // Get upcoming rides with booking details
    $stmt = $pdo->prepare("
        SELECT 
            r.*,
            COUNT(CASE WHEN b.status = 'confirmed' THEN 1 END) as confirmed_bookings,
            COUNT(CASE WHEN b.status = 'completed' THEN 1 END) as completed_bookings,
            u.first_name, u.last_name
        FROM rides r
        LEFT JOIN bookings b ON r.ride_id = b.ride_id
        LEFT JOIN users u ON r.driver_id = u.user_id
        WHERE r.driver_id = ? 
        AND r.status = 'active'
        AND r.departure_time > NOW()
        GROUP BY r.ride_id
        ORDER BY r.departure_time ASC
        LIMIT 5
    ");
} else {
    // Rider Statistics
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(DISTINCT b.booking_id) as total_rides,
            COUNT(DISTINCT CASE 
                WHEN r.departure_time > NOW() AND b.status = 'confirmed' 
                THEN b.booking_id 
                END) as upcoming_rides,
            COUNT(DISTINCT CASE 
                WHEN (r.departure_time < NOW() OR b.status = 'completed') 
                THEN b.booking_id 
                END) as completed_rides,
            SUM(CASE 
                WHEN b.status IN ('confirmed', 'completed') 
                THEN r.price_per_seat 
                ELSE 0 
            END) as total_spent
        FROM bookings b
        JOIN rides r ON b.ride_id = r.ride_id
        WHERE b.rider_id = ?
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $stats = $stmt->fetch();

    // Get upcoming bookings
    $stmt = $pdo->prepare("
        SELECT b.*, r.*,
               u.first_name as driver_first_name,
               u.last_name as driver_last_name
        FROM bookings b
        JOIN rides r ON b.ride_id = r.ride_id
        JOIN users u ON r.driver_id = u.user_id
        WHERE b.rider_id = ? 
        AND b.status = 'confirmed'
        AND r.status = 'active'
        AND r.departure_time > NOW()
        ORDER BY r.departure_time ASC
        LIMIT 5
    ");
}
$stmt->execute([$_SESSION['user_id']]);
$upcoming_rides = $stmt->fetchAll();

require_once 'includes/header.php';
?>

<div class="container py-5">
    <!-- Welcome Section -->
    <div class="row mb-4">
        <div class="col-md-8">
            <h2>Welcome, <?php echo htmlspecialchars($user['first_name']); ?>!</h2>
            <p class="text-muted">You're logged in as a <?php echo ucfirst($user['user_type']); ?></p>
        </div>
        <div class="col-md-4 text-end">
            <?php if ($user['user_type'] === 'driver'): ?>
                <a href="offer-ride.php" class="btn btn-primary">
                    <i class="bi bi-plus-lg"></i> Offer a Ride
                </a>
            <?php else: ?>
                <a href="find-rides.php" class="btn btn-primary">
                    <i class="bi bi-search"></i> Find a Ride
                </a>
            <?php endif; ?>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="dashboard-stats">
        <div class="stat-card">
            <div class="stat-icon">
                <i class="bi bi-list-check"></i>
            </div>
            <h3>Total Rides</h3>
            <p class="stat-value" id="total-rides"><?php echo $stats['total_rides'] ?? 0; ?></p>
        </div>

        <div class="stat-card">
            <div class="stat-icon">
                <i class="bi bi-clock"></i>
            </div>
            <h3>Upcoming</h3>
            <p class="stat-value" id="upcoming-rides"><?php echo $stats['upcoming_rides'] ?? 0; ?></p>
        </div>

        <div class="stat-card">
            <div class="stat-icon">
                <i class="bi bi-check-circle"></i>
            </div>
            <h3>Completed</h3>
            <p class="stat-value" id="completed-rides"><?php echo $stats['completed_rides'] ?? 0; ?></p>
        </div>

        <div class="stat-card">
            <div class="stat-icon">
                <i class="bi bi-wallet2"></i>
            </div>
            <h3><?php echo $user['user_type'] === 'driver' ? 'Earnings' : 'Spent'; ?></h3>
            <p class="stat-value" id="amount">
                $<?php echo number_format($user['user_type'] === 'driver' ? 
                    ($stats['total_earnings'] ?? 0) : 
                    ($stats['total_spent'] ?? 0), 2); ?>
            </p>
        </div>
    </div>

    <!-- Upcoming Section -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3><?php echo $user['user_type'] === 'driver' ? 'Upcoming Rides' : 'Upcoming Bookings'; ?></h3>
        <?php if (!empty($upcoming_rides)): ?>
            <a href="<?php echo $user['user_type'] === 'driver' ? 'my-rides.php' : 'my-bookings.php'; ?>" 
               class="btn btn-outline-primary">View All</a>
        <?php endif; ?>
    </div>

    <?php if (empty($upcoming_rides)): ?>
        <div class="alert alert-info">
            <p class="mb-0">
                No upcoming <?php echo $user['user_type'] === 'driver' ? 'rides' : 'bookings'; ?>. 
                <a href="<?php echo $user['user_type'] === 'driver' ? 'offer-ride.php' : 'find-rides.php'; ?>">
                    <?php echo $user['user_type'] === 'driver' ? 'Offer a ride?' : 'Find a ride?'; ?>
                </a>
            </p>
        </div>
    <?php else: ?>
        <?php foreach ($upcoming_rides as $ride): ?>
            <div class="card mb-3">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-9">
                            <h5 class="card-title">
                                <i class="bi bi-geo-alt text-primary"></i>
                                <?php echo htmlspecialchars($ride['departure_location']); ?>
                                <i class="bi bi-arrow-right mx-2"></i>
                                <?php echo htmlspecialchars($ride['destination']); ?>
                            </h5>
                            <p class="text-muted mb-2">
                                <i class="bi bi-calendar3"></i>
                                <?php echo date('l, F j, Y', strtotime($ride['departure_time'])); ?>
                                <i class="bi bi-clock ms-3"></i>
                                <?php echo date('g:i A', strtotime($ride['departure_time'])); ?>
                            </p>
                            <?php if ($user['user_type'] === 'driver'): ?>
                                <p class="mb-0">
                                    <i class="bi bi-people"></i>
                                    Bookings: <?php echo $ride['confirmed_bookings']; ?> / <?php echo (4 - $ride['available_seats']); ?>
                                </p>
                            <?php else: ?>
                                <p class="mb-0">
                                    <i class="bi bi-person"></i>
                                    Driver: <?php echo htmlspecialchars($ride['driver_first_name'] . ' ' . $ride['driver_last_name']); ?>
                                </p>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-3 text-end">
                            <div class="price-tag mb-2">
                                $<?php echo number_format($ride['price_per_seat'], 2); ?>
                            </div>
                            <a href="<?php echo $user['user_type'] === 'driver' ? 
                                         'view-ride.php?id=' . $ride['ride_id'] : 
                                         'view-booking.php?id=' . $ride['booking_id']; ?>" 
                               class="btn btn-primary">
                                View Details
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<?php if ($user['user_type'] === 'driver'): ?>
<script>
function updateDriverStats() {
    fetch('update-stats.php')
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                console.error(data.error);
                return;
            }
            
            document.getElementById('total-rides').textContent = data.total_rides;
            document.getElementById('upcoming-rides').textContent = data.upcoming_rides;
            document.getElementById('completed-rides').textContent = data.completed_rides;
            document.getElementById('amount').textContent = 
                '$' + Number(data.total_earnings ?? 0).toFixed(2);
            
            if (data.rides_completed) {
                location.reload();
            }
        })
        .catch(error => console.error('Error updating stats:', error));
}

setInterval(updateDriverStats, 60000);

setInterval(() => {
    fetch('update-ride-status.php')
        .then(response => response.json())
        .then(data => {
            if (data.rides_updated) {
                updateDriverStats();
            }
        })
        .catch(error => console.error('Error updating ride statuses:', error));
}, 300000);
</script>
<?php endif; ?>

<?php require_once 'includes/footer.php'; ?>