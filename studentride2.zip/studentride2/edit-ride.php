<?php
require_once 'php/config.php';
require_once 'php/db.php';
require_once 'php/functions.php';
session_start();

// Check if user is logged in and is a driver
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'driver') {
    header("Location: login.php");
    exit();
}

$pageTitle = "Edit Ride";
$error = null;
$success = null;
$ride = null;

// Get ride ID from URL
$ride_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

try {
    // Get ride details
    $stmt = $pdo->prepare("
        SELECT * FROM rides 
        WHERE ride_id = ? AND driver_id = ? AND departure_time > NOW()
    ");
    $stmt->execute([$ride_id, $_SESSION['user_id']]);
    $ride = $stmt->fetch();

    if (!$ride) {
        throw new Exception("Ride not found or cannot be edited.");
    }

    // Handle form submission
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $departure_location = sanitize_input($_POST['departure_location']);
        $destination = sanitize_input($_POST['destination']);
        $departure_time = $_POST['departure_time'];
        $price_per_seat = (float)$_POST['price_per_seat'];

        // Basic validation
        if (strtotime($departure_time) < time()) {
            throw new Exception("Departure time must be in the future");
        }

        if ($price_per_seat <= 0) {
            throw new Exception("Price must be greater than 0");
        }

        $stmt = $pdo->prepare("
            UPDATE rides 
            SET departure_location = ?,
                destination = ?,
                departure_time = ?,
                price_per_seat = ?
            WHERE ride_id = ? AND driver_id = ?
        ");

        if ($stmt->execute([
            $departure_location,
            $destination,
            $departure_time,
            $price_per_seat,
            $ride_id,
            $_SESSION['user_id']
        ])) {
            $success = "Ride updated successfully!";
            // Refresh ride data
            $stmt = $pdo->prepare("SELECT * FROM rides WHERE ride_id = ?");
            $stmt->execute([$ride_id]);
            $ride = $stmt->fetch();
        } else {
            $error = "Failed to update ride";
        }
    }
} catch (Exception $e) {
    $error = $e->getMessage();
}

require_once 'includes/header.php';
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h3 class="mb-0">Edit Ride</h3>
                </div>
                <div class="card-body">
                    <?php if ($error): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                    <?php endif; ?>

                    <?php if ($success): ?>
                        <div class="alert alert-success">
                            <?php echo $success; ?>
                            <a href="view-ride.php?id=<?php echo $ride_id; ?>" class="btn btn-sm btn-primary ms-3">View Ride</a>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="edit-ride.php?id=<?php echo $ride_id; ?>">
                        <div class="mb-3">
                            <label for="departure_location" class="form-label">Departure Location</label>
                            <input type="text" class="form-control" id="departure_location" 
                                   name="departure_location" required 
                                   value="<?php echo htmlspecialchars($ride['departure_location']); ?>">
                        </div>

                        <div class="mb-3">
                            <label for="destination" class="form-label">Destination</label>
                            <input type="text" class="form-control" id="destination" 
                                   name="destination" required 
                                   value="<?php echo htmlspecialchars($ride['destination']); ?>">
                        </div>

                        <div class="mb-3">
                            <label for="departure_time" class="form-label">Departure Time</label>
                            <input type="datetime-local" class="form-control" id="departure_time" 
                                   name="departure_time" required 
                                   value="<?php echo date('Y-m-d\TH:i', strtotime($ride['departure_time'])); ?>">
                        </div>

                        <div class="mb-3">
                            <label for="price_per_seat" class="form-label">Price per Seat ($)</label>
                            <input type="number" class="form-control" id="price_per_seat" 
                                   name="price_per_seat" min="1" step="0.01" required 
                                   value="<?php echo $ride['price_per_seat']; ?>">
                        </div>

                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary">Save Changes</button>
                            <a href="view-ride.php?id=<?php echo $ride_id; ?>" class="btn btn-outline-secondary">Cancel</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>