<?php
// find-rides.php
require_once 'php/config.php';
require_once 'php/db.php';
require_once 'php/functions.php';
session_start();

// Check if user is logged in and is a rider
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'rider') {
    header("Location: login.php");
    exit();
}

$pageTitle = "Find Rides";
$rides = [];
$error = null;
$search_performed = false;

try {
    // Get total count of available rides
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as total_rides
        FROM rides r
        WHERE r.status = 'active' 
        AND r.departure_time > NOW()
        AND r.available_seats > 0
    ");
    $stmt->execute();
    $total = $stmt->fetch();
    $total_rides = $total['total_rides'];

    // Get available rides
    $query = "
        SELECT r.*, 
               u.first_name, 
               u.last_name,
               (4 - r.available_seats) as total_seats,
               r.available_seats as seats_available
        FROM rides r
        JOIN users u ON r.driver_id = u.user_id
        WHERE r.status = 'active'
        AND r.departure_time > NOW()
        AND r.available_seats > 0
    ";

    $params = [];

    // Add search conditions if form submitted
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $search_performed = true;
        
        if (!empty($_POST['from'])) {
            $query .= " AND r.departure_location LIKE ?";
            $params[] = '%' . $_POST['from'] . '%';
        }
        
        if (!empty($_POST['to'])) {
            $query .= " AND r.destination LIKE ?";
            $params[] = '%' . $_POST['to'] . '%';
        }
        
        if (!empty($_POST['date'])) {
            $query .= " AND DATE(r.departure_time) = ?";
            $params[] = $_POST['date'];
        }
    }

    $query .= " ORDER BY r.departure_time ASC";
    
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $rides = $stmt->fetchAll();

} catch (Exception $e) {
    $error = "Error loading rides: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?> - StudentRide</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="container py-5">
        <div class="row">
            <!-- Search Form -->
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <h4>Search Rides</h4>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="find-rides.php">
                            <div class="mb-3">
                                <label for="from" class="form-label">From</label>
                                <input type="text" class="form-control" id="from" name="from" 
                                       value="<?php echo isset($_POST['from']) ? htmlspecialchars($_POST['from']) : ''; ?>">
                            </div>

                            <div class="mb-3">
                                <label for="to" class="form-label">To</label>
                                <input type="text" class="form-control" id="to" name="to"
                                       value="<?php echo isset($_POST['to']) ? htmlspecialchars($_POST['to']) : ''; ?>">
                            </div>

                            <div class="mb-3">
                                <label for="date" class="form-label">Date</label>
                                <input type="date" class="form-control" id="date" name="date"
                                       value="<?php echo isset($_POST['date']) ? htmlspecialchars($_POST['date']) : ''; ?>">
                            </div>

                            <button type="submit" class="btn btn-primary w-100">Search Rides</button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Rides List -->
            <div class="col-md-8">
                <h4 class="mb-4">Available Rides (<?php echo count($rides); ?>)</h4>
                
                <?php if ($error): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>

                <?php if (empty($rides)): ?>
                    <div class="alert alert-info">
                        <h5 class="alert-heading">No rides found!</h5>
                        <?php if ($search_performed): ?>
                            <p>Try adjusting your search criteria.</p>
                        <?php else: ?>
                            <p>No rides are currently available.</p>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <?php foreach ($rides as $ride): ?>
                        <div class="card mb-3">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div>
                                        <h5 class="card-title">
                                            <i class="bi bi-geo-alt text-primary"></i>
                                            <?php echo htmlspecialchars($ride['departure_location']); ?>
                                            <i class="bi bi-arrow-right mx-2"></i>
                                            <?php echo htmlspecialchars($ride['destination']); ?>
                                        </h5>
                                        <p class="text-muted mb-2">
                                            <i class="bi bi-calendar3"></i>
                                            <?php echo date('l, F j, Y', strtotime($ride['departure_time'])); ?>
                                            <i class="bi bi-clock ms-3"></i>
                                            <?php echo date('g:i A', strtotime($ride['departure_time'])); ?>
                                        </p>
                                        <p class="mb-0">
                                            <i class="bi bi-person"></i>
                                            Driver: <?php echo htmlspecialchars($ride['first_name'] . ' ' . $ride['last_name']); ?>
                                        </p>
                                    </div>
                                    <div class="text-end">
                                        <div class="price-tag mb-2">
                                            $<?php echo number_format($ride['price_per_seat'], 2); ?>
                                        </div>
                                        <small class="text-muted d-block mb-2">
                                            <?php echo $ride['seats_available']; ?> seats available
                                        </small>
                                        <a href="book-ride.php?id=<?php echo $ride['ride_id']; ?>" 
                                           class="btn btn-primary">
                                            Book Now
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>