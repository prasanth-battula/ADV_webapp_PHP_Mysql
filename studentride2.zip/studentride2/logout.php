<?php
// logout.php
require_once 'php/config.php';
require_once 'php/db.php';
require_once 'php/functions.php';
session_start();

// Update last activity time before logout
if (isset($_SESSION['user_id'])) {
    $stmt = $pdo->prepare("UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
}

// Destroy session
session_unset();
session_destroy();

// Redirect to login page with logged out message
header("Location: login.php?logged_out=true");
exit();
?>