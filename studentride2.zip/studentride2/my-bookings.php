<?php
// my-bookings.php
require_once 'php/config.php';
require_once 'php/db.php';
require_once 'php/functions.php';
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$pageTitle = "My Bookings";

// Get all bookings for the rider
$stmt = $pdo->prepare("
    SELECT b.*, r.*, 
           u.first_name as driver_first_name, 
           u.last_name as driver_last_name,
           u.phone as driver_phone
    FROM bookings b
    JOIN rides r ON b.ride_id = r.ride_id
    JOIN users u ON r.driver_id = u.user_id
    WHERE b.rider_id = ?
    ORDER BY r.departure_time DESC
");
$stmt->execute([$_SESSION['user_id']]);
$bookings = $stmt->fetchAll();

require_once 'includes/header.php';
?>

<div class="container py-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>My Bookings</h2>
        <a href="find-rides.php" class="btn btn-primary">
            <i class="bi bi-search"></i> Find New Rides
        </a>
    </div>

    <?php if (empty($bookings)): ?>
        <div class="alert alert-info">
            <h4 class="alert-heading">No bookings found!</h4>
            <p>You haven't booked any rides yet. Want to find a ride?</p>
            <hr>
            <p class="mb-0">
                <a href="find-rides.php" class="alert-link">Search available rides</a>
            </p>
        </div>
    <?php else: ?>
        <?php foreach ($bookings as $booking): ?>
            <div class="card mb-3">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-8">
                            <h5 class="card-title">
                                <i class="bi bi-geo-alt text-primary"></i>
                                <?php echo htmlspecialchars($booking['departure_location']); ?>
                                <i class="bi bi-arrow-right mx-2"></i>
                                <?php echo htmlspecialchars($booking['destination']); ?>
                            </h5>
                            <p class="card-text">
                                <i class="bi bi-calendar3"></i>
                                <?php echo date('l, F j, Y', strtotime($booking['departure_time'])); ?>
                                <i class="bi bi-clock ms-3"></i>
                                <?php echo date('g:i A', strtotime($booking['departure_time'])); ?>
                            </p>
                            <p class="card-text">
                                <i class="bi bi-person"></i>
                                Driver: <?php echo htmlspecialchars($booking['driver_first_name'] . ' ' . $booking['driver_last_name']); ?>
                                <?php if ($booking['driver_phone']): ?>
                                    <span class="ms-3">
                                        <i class="bi bi-telephone"></i>
                                        <?php echo htmlspecialchars($booking['driver_phone']); ?>
                                    </span>
                                <?php endif; ?>
                            </p>
                        </div>
                        <div class="col-md-4 text-end">
                            <div class="price-tag mb-2">
                                $<?php echo number_format($booking['price_per_seat'], 2); ?>
                            </div>
                            <span class="badge <?php echo getBadgeClass($booking['status']); ?>">
                                <?php echo ucfirst($booking['status']); ?>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<?php
// Helper function for badge colors
function getBadgeClass($status) {
    switch ($status) {
        case 'confirmed':
            return 'bg-success';
        case 'pending':
            return 'bg-warning';
        case 'cancelled':
            return 'bg-danger';
        case 'completed':
            return 'bg-info';
        default:
            return 'bg-secondary';
    }
}

require_once 'includes/footer.php';
?>