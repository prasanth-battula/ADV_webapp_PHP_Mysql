<?php
// my-rides.php
require_once 'php/config.php';
require_once 'php/db.php';
require_once 'php/functions.php';
session_start();

// Check if user is logged in and is a driver
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'driver') {
    header("Location: login.php");
    exit();
}

$pageTitle = "My Rides";

// Update the rides query in my-rides.php
$stmt = $pdo->prepare("
    SELECT r.*,
           COUNT(DISTINCT CASE WHEN b.status = 'confirmed' THEN b.booking_id END) as confirmed_bookings,
           COUNT(DISTINCT b.booking_id) as total_bookings
    FROM rides r
    LEFT JOIN bookings b ON r.ride_id = b.ride_id
    WHERE r.driver_id = ?
    GROUP BY r.ride_id
    ORDER BY r.departure_time DESC
");
$stmt->execute([$_SESSION['user_id']]);
$rides = $stmt->fetchAll();

require_once 'includes/header.php';
?>

<div class="container py-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>My Rides</h2>
        <a href="offer-ride.php" class="btn btn-primary">
            <i class="bi bi-plus-lg"></i> Offer New Ride
        </a>
    </div>

    <?php if (empty($rides)): ?>
        <div class="alert alert-info">
            <h4 class="alert-heading">No rides found!</h4>
            <p>You haven't offered any rides yet. Want to offer a ride?</p>
            <hr>
            <p class="mb-0">
                <a href="offer-ride.php" class="alert-link">Offer a ride</a>
            </p>
        </div>
    <?php else: ?>
        <?php foreach ($rides as $ride): ?>
            <div class="card mb-3">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-8">
                            <h5 class="card-title">
                                <i class="bi bi-geo-alt text-primary"></i>
                                <?php echo htmlspecialchars($ride['departure_location']); ?>
                                <i class="bi bi-arrow-right mx-2"></i>
                                <?php echo htmlspecialchars($ride['destination']); ?>
                            </h5>
                            <p class="card-text">
                                <i class="bi bi-calendar3"></i>
                                <?php echo date('l, F j, Y', strtotime($ride['departure_time'])); ?>
                                <i class="bi bi-clock ms-3"></i>
                                <?php echo date('g:i A', strtotime($ride['departure_time'])); ?>
                            </p>
                            <p class="card-text">
                                <i class="bi bi-people"></i>
                                Bookings: <?php echo $ride['total_bookings']; ?> / <?php echo 4 - $ride['available_seats']; ?>
                                <span class="ms-3">
                                    <i class="bi bi-cash"></i>
                                    $<?php echo number_format($ride['price_per_seat'], 2); ?> per seat
                                </span>
                            </p>
                        </div>
                        <div class="col-md-4 text-end">
                            <span class="badge <?php echo getRideBadgeClass($ride['status']); ?>">
                                <?php echo ucfirst($ride['status']); ?>
                            </span>
                            <?php if ($ride['departure_time'] > date('Y-m-d H:i:s')): ?>
                                <div class="mt-2">
                                    <a href="edit-ride.php?id=<?php echo $ride['ride_id']; ?>" 
                                       class="btn btn-outline-primary btn-sm">
                                        <i class="bi bi-pencil"></i> Edit
                                    </a>
                                    <?php if ($ride['status'] === 'active'): ?>
                                        <button class="btn btn-outline-danger btn-sm" 
                                                onclick="cancelRide(<?php echo $ride['ride_id']; ?>)">
                                            <i class="bi bi-x-circle"></i> Cancel
                                        </button>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<script>
function cancelRide(rideId) {
    if (confirm('Are you sure you want to cancel this ride?')) {
        fetch('cancel-ride.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'ride_id=' + rideId
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert(data.message || 'Error canceling ride');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error canceling ride');
        });
    }
}
</script>

<?php
// Helper function for ride status badge colors
function getRideBadgeClass($status) {
    switch ($status) {
        case 'active':
            return 'bg-success';
        case 'pending':
            return 'bg-warning';
        case 'cancelled':
            return 'bg-danger';
        case 'completed':
            return 'bg-info';
        default:
            return 'bg-secondary';
    }
}

require_once 'includes/footer.php';
?>