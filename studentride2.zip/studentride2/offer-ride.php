<?php
// offer-ride.php
require_once 'php/config.php';
require_once 'php/db.php';
require_once 'php/functions.php';
session_start();

// Check if user is logged in and is a driver
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'driver') {
    header("Location: login.php");
    exit();
}

$pageTitle = "Offer a Ride";
$error = null;
$success = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $departure_location = sanitize_input($_POST['departure_location']);
        $destination = sanitize_input($_POST['destination']);
        $departure_time = $_POST['departure_time'];
        $available_seats = (int)$_POST['available_seats'];
        $price_per_seat = (float)$_POST['price_per_seat'];

        // Basic validation
        if (strtotime($departure_time) < time()) {
            throw new Exception("Departure time must be in the future");
        }

        if ($available_seats < 1 || $available_seats > 4) {
            throw new Exception("Available seats must be between 1 and 4");
        }

        if ($price_per_seat <= 0) {
            throw new Exception("Price must be greater than 0");
        }

        $stmt = $pdo->prepare("
            INSERT INTO rides (
                driver_id, departure_location, destination, 
                departure_time, available_seats, price_per_seat, status
            ) VALUES (?, ?, ?, ?, ?, ?, 'active')
        ");

        if ($stmt->execute([
            $_SESSION['user_id'],
            $departure_location,
            $destination,
            $departure_time,
            $available_seats,
            $price_per_seat
        ])) {
            $success = "Ride offered successfully!";
        }
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

require_once 'includes/header.php';
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h3 class="mb-0">Offer a Ride</h3>
                </div>
                <div class="card-body">
                    <?php if ($error): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                    <?php endif; ?>

                    <?php if ($success): ?>
                        <div class="alert alert-success"><?php echo $success; ?></div>
                    <?php endif; ?>

                    <form method="POST" action="offer-ride.php" id="offerRideForm">
                        <div class="mb-3">
                            <label for="departure_location" class="form-label">Departure Location</label>
                            <input type="text" class="form-control" id="departure_location" 
                                   name="departure_location" required>
                        </div>

                        <div class="mb-3">
                            <label for="destination" class="form-label">Destination</label>
                            <input type="text" class="form-control" id="destination" 
                                   name="destination" required>
                        </div>

                        <div class="mb-3">
                            <label for="departure_time" class="form-label">Departure Time</label>
                            <input type="datetime-local" class="form-control" id="departure_time" 
                                   name="departure_time" required>
                        </div>

                        <div class="mb-3">
                            <label for="available_seats" class="form-label">Available Seats</label>
                            <select class="form-select" id="available_seats" name="available_seats" required>
                                <option value="1">1 seat</option>
                                <option value="2">2 seats</option>
                                <option value="3">3 seats</option>
                                <option value="4">4 seats</option>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="price_per_seat" class="form-label">Price per Seat ($)</label>
                            <input type="number" class="form-control" id="price_per_seat" 
                                   name="price_per_seat" min="1" step="0.01" required>
                        </div>

                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary">Offer Ride</button>
                            <a href="dashboard.php" class="btn btn-outline-secondary">Cancel</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php 
$extraScripts = <<<EOT
<script>
    // Set minimum datetime to current time
    const departurePicker = document.getElementById('departure_time');
    const now = new Date();
    now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
    departurePicker.min = now.toISOString().slice(0,16);
</script>
EOT;

require_once 'includes/footer.php'; 
?>