<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'studentride');
define('DB_USER', 'root');
define('DB_PASS', '');
define('SITE_URL', 'http://localhost/studentride2/');

?>
