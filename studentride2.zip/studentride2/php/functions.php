<?php
function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

function is_logged_in() {
    return isset($_SESSION['user_id']);
}

function redirect($location) {
    header("Location: " . SITE_URL . $location);
    exit();
}

// New function for phone validation
function validate_phone_number($phone) {
    // Remove any non-digit characters
    $phone = preg_replace('/[^0-9]/', '', $phone);
    // Check if it's exactly 10 digits
    return strlen($phone) === 10;
}

// New function for rating validation
function validate_rating($rating) {
    return is_numeric($rating) && $rating >= 1 && $rating <= 5;
}

function set_flash_message($type, $message) {
    $_SESSION['flash'] = [
        'type' => $type,
        'message' => $message
    ];
}

function display_flash_message() {
    if (isset($_SESSION['flash'])) {
        $message = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return "<div class='alert alert-{$message['type']}'>{$message['message']}</div>";
    }
    return '';
}

// New function to get user rating
function get_user_rating($pdo, $user_id) {
    $stmt = $pdo->prepare("
        SELECT AVG(rating) as average_rating 
        FROM ratings 
        WHERE to_user_id = ?
    ");
    $stmt->execute([$user_id]);
    $result = $stmt->fetch();
    return $result['average_rating'] ? round($result['average_rating'], 1) : null;
}

// New function to check if user can rate
function can_rate_ride($pdo, $ride_id, $user_id) {
    $stmt = $pdo->prepare("
        SELECT 1 FROM ratings 
        WHERE ride_id = ? AND from_user_id = ?
    ");
    $stmt->execute([$ride_id, $user_id]);
    return !$stmt->fetch(); // Returns true if user hasn't rated yet
}

// New function to format phone number
function format_phone_number($phone) {
    $phone = preg_replace('/[^0-9]/', '', $phone);
    return sprintf("(%s) %s-%s",
        substr($phone, 0, 3),
        substr($phone, 3, 3),
        substr($phone, 6, 4)
    );
}
?>