<?php
function track_user_visit($pdo, $user_id) {
    ob_start();
    
    // Get current visit count before any updates
    $browser_visits = isset($_COOKIE['visit_count']) ? (int)$_COOKIE['visit_count'] : 0;
    $browser_visits++;
    
    // Set cookie with longer expiration
    setcookie('visit_count', $browser_visits, time() + (365 * 24 * 60 * 60), '/');
    
    // Record visit with proper timestamp
    $stmt = $pdo->prepare("
        INSERT INTO user_visits (user_id, visit_time) 
        VALUES (?, CURRENT_TIMESTAMP)
    ");
    $stmt->execute([$user_id]);
    
    ob_end_flush();
}

function get_user_visits($pdo, $user_id) {
    // Get accurate visit statistics
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(*) as total_visits,
            DATE(MIN(visit_time)) as first_visit,
            DATE(MAX(visit_time)) as last_visit,
            COUNT(DISTINCT DATE(visit_time)) as unique_days
        FROM user_visits
        WHERE user_id = ?
    ");
    $stmt->execute([$user_id]);
    return $stmt->fetch();
}

function get_visit_statistics($pdo, $user_id) {
    // Get visits per day for last 30 days
    $stmt = $pdo->prepare("
        SELECT 
            DATE(visit_time) as visit_date,
            COUNT(*) as visits_per_day
        FROM user_visits 
        WHERE user_id = ? 
        AND visit_time >= DATE_SUB(CURRENT_DATE, INTERVAL 30 DAY)
        GROUP BY DATE(visit_time)
        ORDER BY visit_date DESC
    ");
    $stmt->execute([$user_id]);
    return $stmt->fetchAll();
}