<?php
require_once 'php/config.php';
require_once 'php/db.php';
require_once 'php/functions.php';
require_once 'php/tracking.php';
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$pageTitle = "Profile";
$error = null;
$success = null;

// Get user data
try {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();

    if (!$user) {
        throw new Exception("User not found");
    }
    
    // Track the current visit
    ob_start();
    track_user_visit($pdo, $_SESSION['user_id']);
    ob_end_flush();
    
    // Get visit statistics
    $visit_stats = get_user_visits($pdo, $_SESSION['user_id']);
    $visit_history = get_visit_statistics($pdo, $_SESSION['user_id']);
    
    // Get browser visits count
    $browser_visits = isset($_COOKIE['visit_count']) ? (int)$_COOKIE['visit_count'] : 1;
    
} catch (Exception $e) {
    $error = "Error loading profile: " . $e->getMessage();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $first_name = sanitize_input($_POST['first_name']);
        $last_name = sanitize_input($_POST['last_name']);
        $phone = isset($_POST['phone']) ? sanitize_input($_POST['phone']) : null;

        if ($phone && !validate_phone_number($phone)) {
            throw new Exception("Please enter a valid 10-digit phone number");
        }

        if ($phone) {
            $phone = format_phone_number($phone);
        }

        $stmt = $pdo->prepare("
            UPDATE users 
            SET first_name = ?, 
                last_name = ?, 
                phone = ?
            WHERE user_id = ?
        ");
        
        if ($stmt->execute([$first_name, $last_name, $phone, $_SESSION['user_id']])) {
            $success = "Profile updated successfully!";
            $stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = ?");
            $stmt->execute([$_SESSION['user_id']]);
            $user = $stmt->fetch();
        } else {
            $error = "Failed to update profile";
        }
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

require_once 'includes/header.php';
?>

<div class="container py-5">
    <div class="row">
        <!-- Profile Information -->
        <div class="col-md-4">
            <div class="card mb-4">
                <div class="card-body text-center">
                    <div class="mb-3">
                        <i class="bi bi-person-circle" style="font-size: 5rem;"></i>
                    </div>
                    <h4><?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?></h4>
                    <p class="text-muted mb-1"><?php echo ucfirst($user['user_type']); ?></p>
                    <p class="text-muted mb-4">Member since <?php echo date('F Y', strtotime($user['created_at'])); ?></p>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Contact Information</h5>
                    <p class="mb-1"><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
                    <p class="mb-1"><strong>Phone:</strong> <?php echo $user['phone'] ? htmlspecialchars($user['phone']) : 'Not set'; ?></p>
                </div>
            </div>

            <!-- Visit Statistics Card -->
            <div class="card mt-4">
                <div class="card-header">
                    <h5 class="card-title mb-0">Visit Statistics</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-12">
                            <p><strong>Total Visits:</strong> <?php echo $visit_stats['total_visits']; ?></p>
                            <p><strong>First Visit:</strong> <?php echo date('F j, Y', strtotime($visit_stats['first_visit'])); ?></p>
                            <p><strong>Last Visit:</strong> <?php echo date('F j, Y', strtotime($visit_stats['last_visit'])); ?></p>
                            
                        </div>
                        <div class="col-12 mt-3">
                            <h6>Recent Activity</h6>
                            <ul class="list-unstyled">
                                <?php foreach($visit_history as $visit): ?>
                                    <li>
                                        <?php echo date('M j', strtotime($visit['visit_date'])); ?>:
                                        <?php echo $visit['visits_per_day']; ?> visits
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Edit Profile Form -->
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h4 class="mb-0">Edit Profile</h4>
                </div>
                <div class="card-body">
                    <?php if ($error): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                    <?php endif; ?>

                    <?php if ($success): ?>
                        <div class="alert alert-success"><?php echo $success; ?></div>
                    <?php endif; ?>

                    <form method="POST" action="profile.php">
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="first_name" class="form-label">First Name</label>
                                <input type="text" class="form-control" id="first_name" name="first_name" 
                                       value="<?php echo htmlspecialchars($user['first_name']); ?>" required>
                            </div>
                            <div class="col-md-6">
                                <label for="last_name" class="form-label">Last Name</label>
                                <input type="text" class="form-control" id="last_name" name="last_name" 
                                       value="<?php echo htmlspecialchars($user['last_name']); ?>" required>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="phone" class="form-label">Phone Number</label>
                            <input type="tel" class="form-control" id="phone" name="phone" 
                                   value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>" 
                                   pattern="[0-9]{10}" 
                                   title="Please enter a valid 10-digit phone number">
                            <small class="text-muted">Format: 1234567890 (10 digits only)</small>
                        </div>

                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary">Save Changes</button>
                            <a href="dashboard.php" class="btn btn-outline-secondary">Cancel</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>