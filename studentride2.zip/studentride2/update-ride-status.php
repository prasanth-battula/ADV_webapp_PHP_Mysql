<?php
// update-ride-status.php
require_once 'php/config.php';
require_once 'php/db.php';

header('Content-Type: application/json');

try {
    // Begin transaction
    $pdo->beginTransaction();

    // Update completed rides
    $stmt = $pdo->prepare("
        UPDATE rides r
        SET status = 'completed'
        WHERE status = 'active'
        AND departure_time < NOW()
    ");
    $updated_rides = $stmt->execute();

    // Update bookings for completed rides
    $stmt = $pdo->prepare("
        UPDATE bookings b
        JOIN rides r ON b.ride_id = r.ride_id
        SET b.status = 'completed'
        WHERE r.status = 'completed'
        AND b.status = 'confirmed'
    ");
    $updated_bookings = $stmt->execute();

    // Calculate earnings for completed rides
    $stmt = $pdo->prepare("
        UPDATE rides r
        SET earnings = (
            SELECT COUNT(*) * r.price_per_seat
            FROM bookings b
            WHERE b.ride_id = r.ride_id
            AND b.status = 'completed'
        )
        WHERE r.status = 'completed'
        AND r.earnings IS NULL
    ");
    $stmt->execute();

    $pdo->commit();

    echo json_encode([
        'success' => true,
        'rides_updated' => $updated_rides && $stmt->rowCount() > 0,
        'bookings_updated' => $updated_bookings && $stmt->rowCount() > 0
    ]);

} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>