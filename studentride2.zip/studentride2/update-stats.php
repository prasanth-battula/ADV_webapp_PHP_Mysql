<?php
// update-stats.php
require_once 'php/config.php';
require_once 'php/db.php';
session_start();

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'Not authorized']);
    exit();
}

try {
    // Get user type
    $stmt = $pdo->prepare("SELECT user_type FROM users WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();

    if ($user['user_type'] === 'driver') {
        $stmt = $pdo->prepare("
            SELECT 
                -- Total Rides (All non-cancelled rides)
                COUNT(DISTINCT r.ride_id) as total_rides,
                
                -- Upcoming Rides (Future rides that are active)
                COUNT(DISTINCT CASE 
                    WHEN r.departure_time > NOW() AND r.status = 'active' 
                    THEN r.ride_id 
                    END) as upcoming_rides,
                
                -- Completed Rides (Past rides or marked as completed)
                COUNT(DISTINCT CASE 
                    WHEN (r.departure_time < NOW() OR r.status = 'completed')
                    AND r.status != 'cancelled' 
                    THEN r.ride_id 
                    END) as completed_rides,
                
                -- Total Earnings
                (
                    SELECT COALESCE(SUM(
                        CASE 
                            WHEN r2.status = 'completed' 
                            THEN (
                                SELECT COUNT(*) 
                                FROM bookings b2 
                                WHERE b2.ride_id = r2.ride_id 
                                AND b2.status = 'completed'
                            ) * r2.price_per_seat
                            WHEN r2.status = 'active' AND r2.departure_time < NOW() 
                            THEN (
                                SELECT COUNT(*) 
                                FROM bookings b2 
                                WHERE b2.ride_id = r2.ride_id 
                                AND b2.status = 'confirmed'
                            ) * r2.price_per_seat
                            ELSE 0
                        END
                    ), 0)
                    FROM rides r2
                    WHERE r2.driver_id = r.driver_id
                ) as total_earnings
            FROM rides r
            WHERE r.driver_id = ?
            GROUP BY r.driver_id
        ");
        $stmt->execute([$_SESSION['user_id']]);
        $stats = $stmt->fetch();

        // Check for newly completed rides
        $stmt = $pdo->prepare("
            SELECT COUNT(*) as completed
            FROM rides
            WHERE driver_id = ?
            AND status = 'completed'
            AND departure_time > DATE_SUB(NOW(), INTERVAL 5 MINUTE)
        ");
        $stmt->execute([$_SESSION['user_id']]);
        $completed = $stmt->fetch();
        
        $stats['rides_completed'] = $completed['completed'] > 0;
        
    } else {
        // Rider Statistics
        $stmt = $pdo->prepare("
            SELECT 
                COUNT(DISTINCT b.booking_id) as total_rides,
                COUNT(DISTINCT CASE 
                    WHEN r.departure_time > NOW() AND b.status = 'confirmed' 
                    THEN b.booking_id 
                    END) as upcoming_rides,
                COUNT(DISTINCT CASE 
                    WHEN (r.departure_time < NOW() OR b.status = 'completed') 
                    THEN b.booking_id 
                    END) as completed_rides,
                SUM(CASE 
                    WHEN b.status IN ('confirmed', 'completed') 
                    THEN r.price_per_seat 
                    ELSE 0 
                END) as total_spent
            FROM bookings b
            JOIN rides r ON b.ride_id = r.ride_id
            WHERE b.rider_id = ?
        ");
        $stmt->execute([$_SESSION['user_id']]);
        $stats = $stmt->fetch();
    }
    
    echo json_encode($stats);
} catch (Exception $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
?>