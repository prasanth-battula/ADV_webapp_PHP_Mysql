<?php
require_once 'php/config.php';
require_once 'php/db.php';
require_once 'php/functions.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$pageTitle = "View Booking";
$error = null;
$booking = null;

// Get booking ID from URL
$booking_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

try {
    // Get booking details with ride and driver information
    $stmt = $pdo->prepare("
        SELECT b.*, r.*,
               u.first_name as driver_first_name,
               u.last_name as driver_last_name,
               u.email as driver_email,
               u.phone as driver_phone
        FROM bookings b
        JOIN rides r ON b.ride_id = r.ride_id
        JOIN users u ON r.driver_id = u.user_id
        WHERE b.booking_id = ? AND b.rider_id = ?
    ");
    $stmt->execute([$booking_id, $_SESSION['user_id']]);
    $booking = $stmt->fetch();

    if (!$booking) {
        throw new Exception("Booking not found.");
    }

} catch (Exception $e) {
    $error = $e->getMessage();
}

require_once 'includes/header.php';
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <?php if ($error): ?>
                <div class="alert alert-danger">
                    <?php echo $error; ?>
                    <a href="dashboard.php" class="btn btn-outline-danger btn-sm ms-3">Back to Dashboard</a>
                </div>
            <?php else: ?>
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h3 class="mb-0">Booking Details</h3>
                        <span class="badge <?php echo getStatusBadgeClass($booking['status']); ?>">
                            <?php echo ucfirst($booking['status']); ?>
                        </span>
                    </div>
                    <div class="card-body">
                        <div class="mb-4">
                            <h4>Ride Information</h4>
                            <p class="mb-2">
                                <i class="bi bi-geo-alt text-primary"></i>
                                From: <strong><?php echo htmlspecialchars($booking['departure_location']); ?></strong>
                            </p>
                            <p class="mb-2">
                                <i class="bi bi-geo-alt-fill text-success"></i>
                                To: <strong><?php echo htmlspecialchars($booking['destination']); ?></strong>
                            </p>
                            <p class="mb-2">
                                <i class="bi bi-calendar3"></i>
                                Date: <strong><?php echo date('l, F j, Y', strtotime($booking['departure_time'])); ?></strong>
                            </p>
                            <p class="mb-2">
                                <i class="bi bi-clock"></i>
                                Time: <strong><?php echo date('g:i A', strtotime($booking['departure_time'])); ?></strong>
                            </p>
                            <p class="mb-2">
                                <i class="bi bi-cash"></i>
                                Price: <strong>$<?php echo number_format($booking['price_per_seat'], 2); ?></strong>
                            </p>
                        </div>

                        <div class="mb-4">
                            <h4>Driver Information</h4>
                            <p class="mb-2">
                                <i class="bi bi-person"></i>
                                Name: <strong><?php echo htmlspecialchars($booking['driver_first_name'] . ' ' . $booking['driver_last_name']); ?></strong>
                            </p>
                            <?php if ($booking['driver_email']): ?>
                                <p class="mb-2">
                                    <i class="bi bi-envelope"></i>
                                    Email: <a href="mailto:<?php echo htmlspecialchars($booking['driver_email']); ?>">
                                        <?php echo htmlspecialchars($booking['driver_email']); ?>
                                    </a>
                                </p>
                            <?php endif; ?>
                            <?php if ($booking['driver_phone']): ?>
                                <p class="mb-2">
                                    <i class="bi bi-telephone"></i>
                                    Phone: <strong><?php echo htmlspecialchars($booking['driver_phone']); ?></strong>
                                </p>
                            <?php endif; ?>
                        </div>

                        <div class="d-flex justify-content-between align-items-center mt-4">
                            <?php if ($booking['status'] === 'confirmed' && strtotime($booking['departure_time']) > time()): ?>
                                <button class="btn btn-danger" onclick="cancelBooking(<?php echo $booking['booking_id']; ?>)">
                                    Cancel Booking
                                </button>
                            <?php elseif ($booking['status'] === 'cancelled' || $booking['status'] === 'completed'): ?>
                                <a href="find-rides.php" class="btn btn-primary">Book Another Ride</a>
                            <?php endif; ?>
                            <a href="my-bookings.php" class="btn btn-outline-secondary">Back to My Bookings</a>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
function cancelBooking(bookingId) {
    if (confirm('Are you sure you want to cancel this booking?')) {
        fetch('cancel-booking.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'booking_id=' + bookingId
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                window.location.href = 'my-bookings.php';
            } else {
                alert(data.message || 'Error canceling booking');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error canceling booking');
        });
    }
}
</script>

<?php
function getStatusBadgeClass($status) {
    switch ($status) {
        case 'confirmed':
            return 'bg-success';
        case 'cancelled':
            return 'bg-danger';
        case 'completed':
            return 'bg-info';
        default:
            return 'bg-secondary';
    }
}

require_once 'includes/footer.php';
?>