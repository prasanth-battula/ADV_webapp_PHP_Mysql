<?php
require_once 'php/config.php';
require_once 'php/db.php';
require_once 'php/functions.php';
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$pageTitle = "View Ride";
$error = null;
$ride = null;
$bookings = [];

// Get ride ID from URL
$ride_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

try {
    // Get ride details
    $stmt = $pdo->prepare("
        SELECT r.*, 
               u.first_name, u.last_name, u.email, u.phone
        FROM rides r
        JOIN users u ON r.driver_id = u.user_id
        WHERE r.ride_id = ? AND r.driver_id = ?
    ");
    $stmt->execute([$ride_id, $_SESSION['user_id']]);
    $ride = $stmt->fetch();

    if (!$ride) {
        throw new Exception("Ride not found or you don't have permission to view it.");
    }

    // Get bookings for this ride
    $stmt = $pdo->prepare("
        SELECT b.*, 
               u.first_name, u.last_name, u.email, u.phone
        FROM bookings b
        JOIN users u ON b.rider_id = u.user_id
        WHERE b.ride_id = ?
        ORDER BY b.created_at DESC
    ");
    $stmt->execute([$ride_id]);
    $bookings = $stmt->fetchAll();

} catch (Exception $e) {
    $error = $e->getMessage();
}

require_once 'includes/header.php';
?>

<div class="container py-5">
    <?php if ($error): ?>
        <div class="alert alert-danger">
            <?php echo $error; ?>
            <a href="dashboard.php" class="btn btn-outline-danger btn-sm ms-3">Back to Dashboard</a>
        </div>
    <?php else: ?>
        <div class="row">
            <!-- Ride Details -->
            <div class="col-md-8">
                <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h4 class="mb-0">Ride Details</h4>
                        <span class="badge <?php echo getRideBadgeClass($ride['status']); ?>">
                            <?php echo ucfirst($ride['status']); ?>
                        </span>
                    </div>
                    <div class="card-body">
                        <div class="ride-info">
                            <p class="mb-3">
                                <i class="bi bi-geo-alt text-primary"></i>
                                <strong>From:</strong> <?php echo htmlspecialchars($ride['departure_location']); ?>
                            </p>
                            <p class="mb-3">
                                <i class="bi bi-geo-alt-fill text-success"></i>
                                <strong>To:</strong> <?php echo htmlspecialchars($ride['destination']); ?>
                            </p>
                            <p class="mb-3">
                                <i class="bi bi-calendar3"></i>
                                <strong>Date:</strong> <?php echo date('l, F j, Y', strtotime($ride['departure_time'])); ?>
                            </p>
                            <p class="mb-3">
                                <i class="bi bi-clock"></i>
                                <strong>Time:</strong> <?php echo date('g:i A', strtotime($ride['departure_time'])); ?>
                            </p>
                            <p class="mb-3">
                                <i class="bi bi-cash"></i>
                                <strong>Price per seat:</strong> $<?php echo number_format($ride['price_per_seat'], 2); ?>
                            </p>
                            <p class="mb-3">
                                <i class="bi bi-person-fill"></i>
                                <strong>Available seats:</strong> <?php echo $ride['available_seats']; ?> of 4
                            </p>
                        </div>

                        <div class="mt-4">
                            <?php if ($ride['departure_time'] > date('Y-m-d H:i:s')): ?>
                                <a href="edit-ride.php?id=<?php echo $ride_id; ?>" class="btn btn-primary">
                                    <i class="bi bi-pencil"></i> Edit Ride
                                </a>
                                <?php if ($ride['status'] === 'active'): ?>
                                    <button class="btn btn-danger ms-2" onclick="cancelRide(<?php echo $ride_id; ?>)">
                                        <i class="bi bi-x-circle"></i> Cancel Ride
                                    </button>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Bookings -->
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <h4 class="mb-0">Bookings (<?php echo count($bookings); ?>)</h4>
                    </div>
                    <div class="card-body">
                        <?php if (empty($bookings)): ?>
                            <p class="text-muted text-center mb-0">No bookings yet</p>
                        <?php else: ?>
                            <?php foreach ($bookings as $booking): ?>
                                <div class="booking-item mb-3 pb-3 border-bottom">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <div>
                                            <h5 class="mb-1">
                                                <?php echo htmlspecialchars($booking['first_name'] . ' ' . $booking['last_name']); ?>
                                            </h5>
                                            <p class="text-muted mb-1">
                                                <small>
                                                    <i class="bi bi-envelope"></i>
                                                    <?php echo htmlspecialchars($booking['email']); ?>
                                                </small>
                                            </p>
                                            <?php if ($booking['phone']): ?>
                                                <p class="text-muted mb-1">
                                                    <small>
                                                        <i class="bi bi-telephone"></i>
                                                        <?php echo htmlspecialchars($booking['phone']); ?>
                                                    </small>
                                                </p>
                                            <?php endif; ?>
                                        </div>
                                        <span class="badge <?php echo getBookingBadgeClass($booking['status']); ?>">
                                            <?php echo ucfirst($booking['status']); ?>
                                        </span>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<script>
function cancelRide(rideId) {
    if (confirm('Are you sure you want to cancel this ride? All bookings will be cancelled.')) {
        fetch('cancel-ride.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'ride_id=' + rideId
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                window.location.reload();
            } else {
                alert(data.message || 'Error canceling ride');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error canceling ride');
        });
    }
}
</script>

<?php 
function getRideBadgeClass($status) {
    switch ($status) {
        case 'active':
            return 'bg-success';
        case 'pending':
            return 'bg-warning';
        case 'cancelled':
            return 'bg-danger';
        case 'completed':
            return 'bg-info';
        default:
            return 'bg-secondary';
    }
}

function getBookingBadgeClass($status) {
    switch ($status) {
        case 'confirmed':
            return 'bg-success';
        case 'pending':
            return 'bg-warning';
        case 'cancelled':
            return 'bg-danger';
        case 'completed':
            return 'bg-info';
        default:
            return 'bg-secondary';
    }
}

require_once 'includes/footer.php'; 
?>